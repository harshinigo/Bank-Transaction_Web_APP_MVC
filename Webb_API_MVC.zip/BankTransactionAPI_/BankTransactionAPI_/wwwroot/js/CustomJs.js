﻿setTimeout(function () {
    $('.alert').alert('close');
},2500)